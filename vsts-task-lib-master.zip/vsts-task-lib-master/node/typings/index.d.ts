/// <reference path="globals/glob/index.d.ts" />
/// <reference path="globals/minimatch/index.d.ts" />
/// <reference path="globals/mocha/index.d.ts" />
/// <reference path="globals/mockery/index.d.ts" />
/// <reference path="globals/node/index.d.ts" />
/// <reference path="globals/q/index.d.ts" />
/// <reference path="globals/semver/index.d.ts" />
/// <reference path="globals/shelljs/index.d.ts" />
