/// <reference path="typings/index.d.ts" />

import trm = require('./task');
