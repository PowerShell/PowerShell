// this is copied to build output so tests compiling use the just built task lib .d.ts

/// <reference path="index.d.ts" />
/// <reference path="modules/vsts-task-lib/index.d.ts" />