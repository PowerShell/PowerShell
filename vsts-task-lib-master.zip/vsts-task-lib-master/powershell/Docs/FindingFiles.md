# Finding Files

Refer to the Node task guidance for [finding files](../../node/docs/findingfiles.md).

The corresponding functions for PowerShell3 tasks are: [Find-VstsMatch](FullHelp/Find-VstsMatch.md) and [Select-VstsMatch](FullHelp/Select-VstsMatch.md).
